// External Dependencies
import React, { Component } from 'react';


class WP_Divi_Table_Row extends Component {

  static slug = 'wp_divi_table_row';

  /**
   * Module render in VB
   * Basically WP_Divi_Table_Row->render() equivalent in JSX
   */
  render() {

    return (

      ''

    );

  }
  
}

export default WP_Divi_Table_Row;
