// Internal Dependencies
import wpDiviTable from './wpDiviTable/wpDiviTable';

import wpDiviTableRow from './wpDiviTableRow/wpDiviTableRow';


export default [

  wpDiviTable,

  wpDiviTableRow
  
];
